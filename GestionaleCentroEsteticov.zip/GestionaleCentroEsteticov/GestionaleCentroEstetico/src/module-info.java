/**
 * 
 */
/**
 * @author Nunzioo
 *
 */
module GestionaleCentroEsteticov {
	requires java.desktop;
	requires java.sql;
	requires jcalendar;
	requires pdfbox.app;
}